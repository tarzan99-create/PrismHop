# Prism Hop V3.6 — release foundation

This source advances the V3.5 Android shell without changing the locked Prism Hop gameplay.

Implemented without external account setup:
- Android fullscreen/local WebView shell retained
- native haptic bridge fixed and mapped for hop, Perfect, Fragment, Flow and death
- app lifecycle + network state bridge retained
- WebView safe-browsing / file-origin hardening
- renderer-crash recovery
- opt-in local Daily Race reminder scheduler (23:30 UTC, inexact; permission still belongs to the player)
- notification channel and receiver
- V3.6 Android client identity supported by the live backend
- privacy preferences backend: analytics defaults OFF; notification categories default OFF
- authenticated account-deletion backend with explicit confirmation and profile-photo cleanup
- sole-owner deletion protection so the moderation owner role cannot be accidentally orphaned
- integrity/verified-leaderboard database indexes added

Still requires owner/account action later:
- Google Play Integrity app binding and server token verification
- Play Console app signing / AAB upload / closed testing
- final notification permission UX approval on a real device
- AdMob / IAP choice and IDs (not added yet)
- analytics/crash provider account if an external provider is chosen (no third-party telemetry is active now)
- Supabase leaked-password protection setting
- final prismhop.co.uk privacy/support pages and Play Console declarations

Build requirements: Android Studio / Android SDK 36 and JDK 17.
