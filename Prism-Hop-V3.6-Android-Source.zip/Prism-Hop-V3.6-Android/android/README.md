# Prism Hop Android V3.5

Production-shell test build for Prism Hop. The game asset is stored as gzip/base64 text and expanded automatically before Android builds.

- Package: `com.zarivostudios.prismhop`
- minSdk: 26
- targetSdk / compileSdk: 36
- WebView fullscreen shell with native haptics, file chooser, backup save, network/lifecycle hooks, and startup audio permission controlled by the app.
- Server Replay V1 stays authoritative for competitive scores.
- Google Play Integrity is intentionally **not claimed active** in this build; the native bridge exposes a foundation status only. Official Spotlight awards remain disabled until real Play Integrity tokens are bound and verified server-side.
