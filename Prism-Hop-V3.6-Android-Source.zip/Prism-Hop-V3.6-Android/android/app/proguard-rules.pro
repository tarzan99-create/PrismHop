-keepclassmembers class com.zarivostudios.prismhop.MainActivity$PrismNativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}
