package com.zarivostudios.prismhop;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.provider.Settings;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.window.OnBackInvokedDispatcher;
import android.widget.Toast;

import org.json.JSONArray;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Calendar;
import java.util.TimeZone;

public final class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 4101;
    private static final int SAVE_BACKUP_REQUEST = 4102;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 4103;
    private static final String APP_VERSION = "3.6.0-test";
    private static final String CHANNEL_ID = "prism_updates";

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingSaveText;
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(7,9,18));
        getWindow().setNavigationBarColor(Color.rgb(7,9,18));
        immersive();
        createNotificationChannel();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(7,9,18));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        if (Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setTextZoom(100);
        webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_BOUND, true);
        webView.addJavascriptInterface(new PrismNativeBridge(), "PrismNative");

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri != null && ("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme()))) {
                    openExternal(uri.toString());
                    return true;
                }
                return false;
            }
            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                Toast.makeText(MainActivity.this, "Prism Hop recovered from a renderer restart.", Toast.LENGTH_SHORT).show();
                recreate();
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pushNetworkState();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent;
                try { intent = params.createIntent(); }
                catch (Exception e) { intent = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE); }
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (ActivityNotFoundException e) { fileCallback = null; Toast.makeText(MainActivity.this, "No file picker is available.", Toast.LENGTH_SHORT).show(); return false; }
                return true;
            }
            @Override public void onPermissionRequest(PermissionRequest request) { request.deny(); }
        });

        registerNetworkMonitor();
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::handleBack);
        }
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, getString(R.string.notification_channel_name), NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription(getString(R.string.notification_channel_description));
            channel.enableVibration(true);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    private boolean isOnline() {
        if (connectivityManager == null) connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        Network n = connectivityManager.getActiveNetwork();
        if (n == null) return false;
        NetworkCapabilities c = connectivityManager.getNetworkCapabilities(n);
        return c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }

    private void registerNetworkMonitor() {
        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        networkCallback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) { pushNetworkState(); }
            @Override public void onLost(Network network) { pushNetworkState(); }
            @Override public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) { pushNetworkState(); }
        };
        try { connectivityManager.registerDefaultNetworkCallback(networkCallback); } catch (Exception ignored) {}
    }

    private void pushNetworkState() {
        if (webView == null) return;
        final boolean online = isOnline();
        runOnUiThread(() -> webView.evaluateJavascript("window.PrismNativeHost?.networkChanged?.(" + online + ");", null));
    }

    private void handleBack() {
        if (webView == null) { finish(); return; }
        webView.evaluateJavascript("String(!!window.PrismNativeHost?.handleBack?.())", value -> {
            if (!"true".equals(value.replace("\"", ""))) finish();
        });
    }

    @Override public void onBackPressed() {
        if (Build.VERSION.SDK_INT < 33) handleBack(); else super.onBackPressed();
    }

    @Override protected void onPause() {
        if (webView != null) {
            webView.evaluateJavascript("window.PrismNativeHost?.onPause?.();", null);
            webView.onPause();
        }
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        immersive();
        if (webView != null) {
            webView.onResume();
            webView.evaluateJavascript("window.PrismNativeHost?.onResume?.();", null);
        }
        pushNetworkState();
    }

    @Override protected void onDestroy() {
        if (connectivityManager != null && networkCallback != null) {
            try { connectivityManager.unregisterNetworkCallback(networkCallback); } catch (Exception ignored) {}
        }
        if (webView != null) {
            webView.removeJavascriptInterface("PrismNative");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            Uri[] result = resultCode == RESULT_OK ? WebChromeClient.FileChooserParams.parseResult(resultCode, data) : null;
            if (fileCallback != null) fileCallback.onReceiveValue(result);
            fileCallback = null;
            return;
        }
        if (requestCode == SAVE_BACKUP_REQUEST) {
            boolean ok = false;
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingSaveText != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) { out.write(pendingSaveText.getBytes(StandardCharsets.UTF_8)); ok = true; }
                } catch (Exception ignored) {}
            }
            pendingSaveText = null;
            final boolean saved = ok;
            if (webView != null) webView.evaluateJavascript("window.PrismNativeHost?.savedBackup?.(" + saved + ");", null);
        }
    }

    private void openExternal(String url) {
        try {
            Uri uri = Uri.parse(url);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null) return;
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception e) { Toast.makeText(this, "Could not open that link.", Toast.LENGTH_SHORT).show(); }
    }

    private void vibrate(String json) {
        try {
            List<Long> times = new ArrayList<>();
            List<Integer> amplitudes = new ArrayList<>();
            if (json.trim().startsWith("[")) {
                JSONArray a = new JSONArray(json);
                for (int i=0;i<a.length();i++) {
                    long raw = Math.max(1, a.getLong(i));
                    boolean active = i % 2 == 0;
                    times.add(active ? Math.max(11, raw) : raw);
                    amplitudes.add(active ? Math.min(220, 90 + i * 28) : 0);
                }
            } else {
                long raw = Long.parseLong(json.trim());
                times.add(Math.max(10, raw * 2));
                amplitudes.add(Math.min(190, 55 + (int) raw * 10));
            }
            long[] t = new long[times.size()]; int[] a = new int[amplitudes.size()];
            for (int i=0;i<t.length;i++) { t[i]=times.get(i); a[i]=amplitudes.get(i); }
            Vibrator vibrator;
            if (Build.VERSION.SDK_INT >= 31) vibrator = getSystemService(VibratorManager.class).getDefaultVibrator();
            else vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vibrator == null || !vibrator.hasVibrator()) return;
            vibrator.vibrate(t.length == 1 ? VibrationEffect.createOneShot(t[0], a[0]) : VibrationEffect.createWaveform(t, a, -1));
        } catch (Exception ignored) {}
    }


    private void scheduleRaceReminder(boolean enabled) {
        AlarmManager alarms=(AlarmManager)getSystemService(ALARM_SERVICE);
        Intent intent=new Intent(this, RaceReminderReceiver.class).setAction("com.zarivostudios.prismhop.RACE_REMINDER");
        PendingIntent pending=PendingIntent.getBroadcast(this,3601,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        if(!enabled){alarms.cancel(pending);return;}
        Calendar utc=Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        utc.set(Calendar.HOUR_OF_DAY,23);utc.set(Calendar.MINUTE,30);utc.set(Calendar.SECOND,0);utc.set(Calendar.MILLISECOND,0);
        if(utc.getTimeInMillis()<=System.currentTimeMillis())utc.add(Calendar.DAY_OF_YEAR,1);
        alarms.setInexactRepeating(AlarmManager.RTC_WAKEUP,utc.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pending);
    }

    private void hapticEvent(String kind) {
        switch(kind==null?"":kind){
            case "fragment" -> vibrate("[12]");
            case "perfect" -> vibrate("[13,22,18]");
            case "flow" -> vibrate("[12,25,18,28,25]");
            case "death" -> vibrate("[32,20,45]");
            default -> vibrate("[11]");
        }
    }

    private final class PrismNativeBridge {
        @JavascriptInterface public String platform() { return "android"; }
        @JavascriptInterface public String appVersion() { return APP_VERSION; }
        @JavascriptInterface public String integrityStatus() { return "foundation_only_play_console_binding_required"; }
        @JavascriptInterface public void haptic(String kind) { runOnUiThread(() -> hapticEvent(kind)); }
        @JavascriptInterface public void setRaceReminder(boolean enabled) { runOnUiThread(() -> scheduleRaceReminder(enabled)); }
        @JavascriptInterface public boolean isOnline() { return MainActivity.this.isOnline(); }
        @JavascriptInterface public void hapticPattern(String json) { runOnUiThread(() -> vibrate(json)); }
        @JavascriptInterface public void openExternal(String url) { runOnUiThread(() -> MainActivity.this.openExternal(url)); }
        @JavascriptInterface public void saveTextFile(String filename, String text) {
            if (text == null || text.length() > 1_000_000) return;
            runOnUiThread(() -> {
                pendingSaveText = text;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE, filename == null ? "Prism-Hop-Progress.json" : filename);
                try { startActivityForResult(intent, SAVE_BACKUP_REQUEST); }
                catch (Exception e) { pendingSaveText = null; if (webView != null) webView.evaluateJavascript("window.PrismNativeHost?.savedBackup?.(false);", null); }
            });
        }
        @JavascriptInterface public void requestNotifications() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
            });
        }
        @JavascriptInterface public void openAppSettings() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))));
        }
    }
}
