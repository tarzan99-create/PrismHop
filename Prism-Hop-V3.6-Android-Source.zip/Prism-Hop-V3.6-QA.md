# Prism Hop V3.6 Release Foundation — QA / handoff

## Completed without owner action

- Live backend migration `v360_release_privacy_foundation` applied.
- Live backend migration `v360_android_client_compatibility` applied.
- `prism-account` Edge Function deployed with custom Supabase Auth validation.
- Privacy preferences are service-only and default to analytics OFF and all notification categories OFF.
- Account deletion requires the literal confirmation `DELETE PRISM HOP ACCOUNT`, removes account-linked game/profile data, and is blocked for the sole moderation owner until ownership is transferred.
- Profile-photo paths are exposed only to the authenticated deletion service so Storage objects can be removed before account deletion.
- Missing integrity/verified-leaderboard FK indexes added.
- V3.6 Android client is accepted by Server Replay V1 and explicitly reports Play Integrity as pending.
- Native haptic bridge mismatch from V3.5 fixed (`PrismNative.haptic(kind)`).
- Local opt-in Daily Race reminder scheduler added for 23:30 UTC.
- WebView safe browsing, file-origin restrictions and renderer restart recovery added.
- No AdMob, IAP SDK or third-party analytics/crash SDK has been added without an owner decision/account.

## Tests

Database rollback assertions passed for:
1. analytics opt-in defaults OFF
2. preference save
3. invalid preference payload rejection
4. deletion preview
5. explicit deletion phrase
6. sole-owner deletion protection
7. complete test-account deletion
8. V3.6 Android client accepted
9. Server Replay V1 retained
10. Play Integrity remains truthfully pending

All inline V3.6 web JavaScript blocks pass `node --check`.
Android source static checks confirm the haptic bridge, reminder bridge, receiver registration and V3.6 version metadata are present.

## Still requires owner / external account action

1. Google Play Console package/app creation or confirmation and Play Integrity binding.
2. App signing / AAB build and upload through an Android SDK/Play build environment.
3. Real-device install test for haptic timing, audio lifecycle, heat, fullscreen, back navigation and notification permission UX.
4. Monetisation decision; then AdMob and/or Play Billing product IDs if chosen.
5. External analytics/crash provider account if chosen. Current release foundation sends no optional telemetry by default.
6. Enable Supabase leaked-password protection in Auth settings.
7. Final privacy/support pages on prismhop.co.uk and Play Console Data Safety/content declarations.

## Security advisor note

Supabase reports INFO notices for RLS-enabled service-only tables with no client policies. These tables are deliberately revoked from anon/authenticated roles and reached through authenticated service endpoints. The remaining WARN is leaked-password protection disabled; this needs the account setting enabled before public launch.
